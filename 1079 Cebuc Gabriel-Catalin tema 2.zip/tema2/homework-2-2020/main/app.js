function addTokens(input, tokens) {
  const termForSearch = "...";
  let correctType = true;
  let inputCopy = input;

  function replaceTokens(res) {
    if (tokens) {
      tokens.map((token) => {
        let stringRezultat = "${" + token.tokenName + "}";
        res = res.replace(termForSearch, stringRezultat);
      });
      return res;
    }
  }
  if (tokens) {
    tokens.map((token) => {
      if (
        token.hasOwnProperty("tokenName") &&
        typeof token.tokenName === "string"
      );
      else correctType = false;
    });
  }
  if (
    (typeof input === "string" || input instanceof String) &&
    input.length >= 7 &&
    correctType &&
    input.includes("...")
  )
    return replaceTokens(inputCopy);
  else {
    if (typeof input !== "string") throw Error("Invalid input");
    else if (input.length < 6)
      throw Error("Input should have at least 6 characters");
    else if (!correctType) throw Error("Invalid array format");
    else return input;
  }
}

const app = {
  addTokens: addTokens,
};

module.exports = app;
